﻿using Microsoft.AspNetCore.Mvc;
using ST10403075_APPR.Data;
using ST10403075_APPR.Models;
using System.Linq;

namespace ST10403075_APPR.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AccountController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Account/Register
        public IActionResult Register()
        {
            return View();
        }

        // POST: Account/Register
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(Volunteer volunteer)
        {
            if (ModelState.IsValid)
            {
                _context.Volunteers.Add(volunteer);
                _context.SaveChanges();

                // After registering, redirect to Login page
                return RedirectToAction("Login");
            }
            return View(volunteer);
        }

        // GET: Account/Login
        public IActionResult Login()
        {
            return View();
        }

        // POST: Account/Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(string name, string password)
        {
            var volunteer = _context.Volunteers
                .FirstOrDefault(v => v.Name == name && v.Password == password);

            if (volunteer != null)
            {
                // ✅ Login success → redirect to Home/Index (or Dashboard)
                return RedirectToAction("Index", "Home");
            }

            // ❌ Login failed
            ViewBag.ErrorMessage = "Invalid name or password.";
            return View();
        }
        public IActionResult Profile()
        {
            return View();
        }
    }
}
    
