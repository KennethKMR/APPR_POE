﻿using Microsoft.AspNetCore.Mvc;

namespace ST10403075_APPR.Controllers
{
    public class DisasterController : Controller
    {
        // GET: Disaster/Report
        public IActionResult Report()
        {
            return View();
        }
    }
}