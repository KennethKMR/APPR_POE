﻿using Microsoft.AspNetCore.Mvc;

namespace ST10403075_APPR.Controllers
{
    public class DonationController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}