﻿using Microsoft.EntityFrameworkCore;
using ST10403075_APPR.Models;

namespace ST10403075_APPR.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Volunteer> Volunteers { get; set; }
    }
}