using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ST10403075_APPR.Views.Account
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
