using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ST10403075_APPR.Views.Disaster
{
    public class ReportModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
