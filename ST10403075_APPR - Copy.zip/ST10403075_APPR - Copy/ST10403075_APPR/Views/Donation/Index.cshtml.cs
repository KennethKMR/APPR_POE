using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ST10403075_APPR.Views.Donation
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
